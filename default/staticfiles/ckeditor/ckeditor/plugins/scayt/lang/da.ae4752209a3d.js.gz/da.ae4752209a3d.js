﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'da', {
	btn_about: 'Om SCAYT',
	btn_dictionaries: 'Ordbøger',
	btn_disable: 'Deaktivér SCAYT',
	btn_enable: 'Aktivér SCAYT',
	btn_langs:'Sprog',
	btn_options: 'Indstillinger',
	text_title: 'Stavekontrol mens du skriver'
});
