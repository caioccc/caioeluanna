﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ug', {
	btn_about: 'شۇئان ئىملا تەكشۈرۈش ھەققىدە',
	btn_dictionaries: 'لۇغەت',
	btn_disable: 'شۇئان ئىملا تەكشۈرۈشنى چەكلە',
	btn_enable: 'شۇئان ئىملا تەكشۈرۈشنى قوزغات',
	btn_langs:'تىل',
	btn_options: 'تاللانما',
	text_title:  'شۇئان ئىملا تەكشۈر'
});
