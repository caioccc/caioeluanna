﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'he', {
	btn_about: 'אודות SCAYT',
	btn_dictionaries: 'מילון',
	btn_disable: 'בטל SCAYT',
	btn_enable: 'אפשר SCAYT',
	btn_langs:'שפות',
	btn_options: 'אפשרויות',
	text_title:  'בדיקת איות בזמן כתיבה (SCAYT)'
});
