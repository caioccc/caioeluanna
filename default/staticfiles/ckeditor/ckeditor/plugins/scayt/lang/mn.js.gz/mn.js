﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'mn', {
	btn_about: 'About SCAYT',
	btn_dictionaries: 'Толь бичгүүд',
	btn_disable: 'Disable SCAYT',
	btn_enable: 'Enable SCAYT',
	btn_langs:'Хэлүүд',
	btn_options: 'Сонголт',
	text_title:  'Spell Check As You Type'
});
