﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'cy', {
	btn_about: 'Ynghylch SCAYT',
	btn_dictionaries: 'Geiriaduron',
	btn_disable: 'Analluogi SCAYT',
	btn_enable: 'Galluogi SCAYT',
	btn_langs:'Ieithoedd',
	btn_options: 'Opsiynau',
	text_title:  'Gwirio\'r Sillafu Wrth Deipio'
});
