﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'af', {
	btn_about: 'SCAYT info',
	btn_dictionaries: 'Woordeboeke',
	btn_disable: 'SCAYT af',
	btn_enable: 'SCAYT aan',
	btn_langs:'Tale',
	btn_options: 'Opsies',
	text_title:  'Speltoets terwyl u tik'
});
